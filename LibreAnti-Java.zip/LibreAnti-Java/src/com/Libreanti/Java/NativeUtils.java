public class NativeUtils {
    public static boolean isAdmin() {
        String os = System.getProperty("os.name").toLowerCase();
        return os.contains("linux") 
            ? System.getProperty("user.name").equals("root")
            : false;
    }
}
