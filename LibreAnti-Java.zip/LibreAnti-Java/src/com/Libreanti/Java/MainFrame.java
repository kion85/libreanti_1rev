import javax.swing.*;

public class MainFrame extends JFrame {
    public MainFrame() {
        setTitle("LibreAnti");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        add(new JLabel("Antivirus GUI"));
    }
}
