public class Main {
    public static void main(String[] args) {
        System.out.println("LibreAnti Java version");
        System.out.println("Admin check: " + checkAdmin());
    }
    
    private static boolean checkAdmin() {
        // Простая проверка прав для Linux
        String os = System.getProperty("os.name").toLowerCase();
        if (os.contains("linux")) {
            return System.getProperty("user.name").equals("root");
        }
        return false;
    }
}
