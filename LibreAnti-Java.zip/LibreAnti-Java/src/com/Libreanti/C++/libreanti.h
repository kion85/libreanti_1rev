#ifndef LIBREANTI_H
#define LIBREANTI_H

#include <vector>
#include <string>
#include <map>
#include <memory>
#include <filesystem>
#include <chrono>
#include <iomanip>
#include <sstream>
#include <unordered_set>
#include <openssl/evp.h>
#include <openssl/err.h>

class LibreAnti {
public:
    // Режимы работы
    enum class SecurityMode { GAMING, WORK, STRICT };

    // Основные функции
    void fullSystemScan();
    void showConsoleMenu();
    int run();

    // Диагностика системы
    void scanBIOS();
    void scanUSB();
    void checkHardware();
    void scanMemory();
    void checkFirmware();
    void detectMalware();
    void analyzeNetwork();
    void checkKernelModules();

    // Защитные функции
    void backupBIOS(const std::string& output_file = "");
    bool resetBIOSPassword();
    void scanWorms();
    void checkOSIntegrity();
    void behavioralAnalysis();
    void memoryProtection();
    void antiRansomware();
    void cloudSandbox(const std::string& file_path);
    void antiPhishing();
    void autoPatching();
    void scanRootkits();
    void checkSuspiciousScripts();
    void monitorUSBChanges();

    // Управление
    void setSecurityMode(SecurityMode mode);
    void enableMemoryProtection(bool enable);

private:
    // Состояние
    SecurityMode current_mode = SecurityMode::WORK;
    bool memory_protection_enabled = true;

    // Внутренние методы
    std::string execCommand(const std::string& cmd);
    bool checkRootAccess();
    std::vector<std::string> findBadUSB();
    void checkCPUVulnerabilities();
    void scanPCIBus();
    void checkBiosBattery();
    void execSystem(const std::string& cmd);
    std::string sha256_file(const std::string& path);
    std::vector<std::string> get_suspicious_files(const std::string& dir);
    std::string generateBackupName();
    void logEvent(const std::string& message);
    bool isBIOSProtected();
    void detectSuspiciousBehavior();
    void analyzeMemoryPatterns();
    void rollbackEncryptedFiles();
    void applySecurityPatches();
    void sendToCloudAnalysis(const std::string& file_path);
    void checkNetworkTraffic();
    void detectHiddenProcesses();
    void analyzeCronJobs();
};

#endif
