#include "libreanti.h"

int main() {
    LibreAnti antivirus;
    return antivirus.run();
}
