// main_console.cpp
#include "libreanti.h"
#include <iostream>

int main() {
    LibreAnti antivirus;
    return antivirus.run();
}
