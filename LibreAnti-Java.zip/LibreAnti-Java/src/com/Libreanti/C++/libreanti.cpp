#include "libreanti.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <cstring>
#include <array>
#include <ctime>
#include <cstdio>
#include <thread>
#include <random>

using namespace std;
using namespace std::filesystem;

// ===================== Вспомогательные функции =====================

string LibreAnti::execCommand(const string& cmd) {
    array<char, 128> buffer;
    string result;
    
    // Кастомный deleter для FILE*
    auto deleter = [](FILE* f) { if (f) pclose(f); };
    unique_ptr<FILE, decltype(deleter)> pipe(popen(cmd.c_str(), "r"), deleter);
    
    if (!pipe) throw runtime_error("Ошибка popen()!");
    
    while (fgets(buffer.data(), buffer.size(), pipe.get()) != nullptr) {
        result += buffer.data();
    }
    return result;
}

void LibreAnti::execSystem(const string& cmd) {
    int ret = system(cmd.c_str());
    (void)ret;
}

bool LibreAnti::checkRootAccess() {
    return getuid() == 0;
}

string LibreAnti::sha256_file(const string& path) {
    ifstream file(path, ios::binary);
    if (!file) return "";

    EVP_MD_CTX* mdctx = EVP_MD_CTX_new();
    const EVP_MD* md = EVP_sha256();
    unsigned char hash[EVP_MAX_MD_SIZE];
    unsigned int hash_len;

    EVP_DigestInit_ex(mdctx, md, NULL);
    
    char buf[1024];
    while (file.read(buf, sizeof(buf))) {
        EVP_DigestUpdate(mdctx, buf, file.gcount());
    }
    EVP_DigestUpdate(mdctx, buf, file.gcount());
    
    EVP_DigestFinal_ex(mdctx, hash, &hash_len);
    EVP_MD_CTX_free(mdctx);

    stringstream ss;
    for (unsigned int i = 0; i < hash_len; i++) {
        ss << hex << setw(2) << setfill('0') << (int)hash[i];
    }

    return ss.str();
}

vector<string> LibreAnti::get_suspicious_files(const string& dir) {
    vector<string> result;
    DIR* dp;
    struct dirent* entry;
    struct stat statbuf;

    if ((dp = opendir(dir.c_str())) == NULL) return result;

    while ((entry = readdir(dp)) != NULL) {
        string full_path = dir + "/" + entry->d_name;
        if (stat(full_path.c_str(), &statbuf) == -1) continue;

        if (entry->d_name[0] == '.' && strcmp(entry->d_name, ".") != 0 && 
            strcmp(entry->d_name, "..") != 0) {
            result.push_back(full_path);
        }

        if (S_ISREG(statbuf.st_mode)) {
            if ((statbuf.st_mode & S_ISUID) || (statbuf.st_mode & S_ISGID)) {
                result.push_back(full_path + " (setuid/setgid)");
            }
        }
    }
    closedir(dp);
    return result;
}

string LibreAnti::generateBackupName() {
    auto now = chrono::system_clock::now();
    time_t time = chrono::system_clock::to_time_t(now);
    stringstream ss;
    ss << "bios_backup_" << put_time(localtime(&time), "%Y%m%d_%H%M%S") << ".rom";
    return ss.str();
}

void LibreAnti::logEvent(const string& message) {
    ofstream logfile("/var/log/libreanti.log", ios::app);
    if (logfile) {
        auto now = chrono::system_clock::now();
        time_t time = chrono::system_clock::to_time_t(now);
        logfile << put_time(localtime(&time), "[%Y-%m-%d %H:%M:%S] ") << message << "\n";
    }
}

// ===================== Основные функции диагностики =====================

void LibreAnti::scanBIOS() {
    cout << "\n=== BIOS Scan ===\n";
    logEvent("Starting BIOS scan");
    
    try {
        string info = execCommand("sudo dmidecode -t bios 2>/dev/null");
        if (info.empty()) {
            cout << "BIOS info unavailable (install dmidecode or run as root)\n";
            return;
        }
        
        cout << "Vendor: " << execCommand("grep -m1 \"Vendor:\" <<< \"" + info + "\" | cut -d: -f2-");
        cout << "Version: " << execCommand("grep -m1 \"Version:\" <<< \"" + info + "\" | cut -d: -f2-");
        
        // Проверка Secure Boot
        if (execCommand("bootctl status 2>/dev/null | grep -q 'Secure Boot: enabled'") == "0") {
            cout << "[SECURE] Secure Boot: Enabled\n";
        } else {
            cout << "[WARNING] Secure Boot: Disabled\n";
        }
    } catch (...) {
        cerr << "BIOS scan failed\n";
        logEvent("BIOS scan failed");
    }
}

void LibreAnti::scanUSB() {
    cout << "\n=== USB Scan ===\n";
    logEvent("Starting USB scan");
    
    try {
        // Основная информация
        cout << "Connected devices:\n";
        execSystem("lsusb");
        
        // Поиск подозрительных устройств
        cout << "\n[Suspicious devices]:\n";
        execSystem("lsusb -v 2>/dev/null | grep -E 'HID|Keyboard|Mouse'");
    } catch (...) {
        cerr << "USB scan failed\n";
        logEvent("USB scan failed");
    }
}

void LibreAnti::checkHardware() {
    cout << "\n=== Hardware Check ===\n";
    logEvent("Starting hardware diagnostics");
    
    try {
        // CPU информация
        cout << "[CPU]:\n";
        execSystem("lscpu | grep -E 'Model name|Cores|MHz'");
        
        // Температуры
        cout << "\n[Temperatures]:\n";
        execSystem("sensors 2>/dev/null || echo 'Install lm-sensors'");
        
        // Проверка дисков
        cout << "\n[Disks]:\n";
        execSystem("lsblk -o NAME,SIZE,TYPE,MOUNTPOINT");
    } catch (...) {
        cerr << "Hardware check failed\n";
        logEvent("Hardware check failed");
    }
}

void LibreAnti::scanMemory() {
    cout << "\n=== Memory Test ===\n";
    logEvent("Starting memory scan");
    
    try {
        // Использование памяти
        execSystem("free -h");
        
        // Поиск ошибок
        if (checkRootAccess()) {
            cout << "\n[Errors]:\n";
            execSystem("sudo grep -i 'error' /var/log/kern.log | grep -i 'memory' | tail -n 5");
        }
    } catch (...) {
        cerr << "Memory scan failed\n";
        logEvent("Memory scan failed");
    }
}

void LibreAnti::checkFirmware() {
    cout << "\n=== Firmware Check ===\n";
    logEvent("Starting firmware scan");
    
    try {
        // Микрокод CPU
        cout << "[Microcode]:\n";
        execSystem("grep microcode /proc/cpuinfo | head -n 1");
        
        // UEFI/BIOS
        cout << "\n[UEFI]:\n";
        execSystem("ls /sys/firmware/efi/efivars 2>/dev/null | head -n 5");
    } catch (...) {
        cerr << "Firmware check failed\n";
        logEvent("Firmware check failed");
    }
}

void LibreAnti::detectMalware() {
    cout << "\n=== Malware Scan ===\n";
    logEvent("Starting malware scan");
    
    try {
        // Поиск подозрительных файлов
        cout << "[Suspicious files]:\n";
        execSystem("find /usr/bin /usr/sbin -type f -executable -print0 | xargs -0 file | grep -i 'setuid'");
        
        // Проверка cron
        cout << "\n[Cron jobs]:\n";
        execSystem("ls -la /etc/cron* 2>/dev/null");
    } catch (...) {
        cerr << "Malware scan failed\n";
        logEvent("Malware scan failed");
    }
}

void LibreAnti::analyzeNetwork() {
    cout << "\n=== Network Analysis ===\n";
    logEvent("Starting network scan");
    
    try {
        // Активные соединения
        cout << "[Connections]:\n";
        execSystem("ss -tulnp");
        
        // ARP таблица
        cout << "\n[ARP]:\n";
        execSystem("ip neigh show");
    } catch (...) {
        cerr << "Network analysis failed\n";
        logEvent("Network analysis failed");
    }
}

void LibreAnti::checkKernelModules() {
    cout << "\n=== Kernel Modules ===\n";
    logEvent("Starting kernel modules scan");
    
    try {
        // Загруженные модули
        cout << "[Loaded modules]:\n";
        execSystem("lsmod | head -n 15");
        
        // Подозрительные модули
        cout << "\n[Suspicious]:\n";
        execSystem("find /lib/modules/$(uname -r) -name '*.ko' -exec file {} \\; | grep -i 'not stripped'");
    } catch (...) {
        cerr << "Kernel modules check failed\n";
        logEvent("Kernel modules check failed");
    }
}

// ===================== Защитные функции =====================

void LibreAnti::fullSystemScan() {
    cout << "\n=== Полное сканирование системы ===\n";
    logEvent("Запуск полного сканирования системы");
    
    scanBIOS();
    scanUSB();
    checkHardware();
    scanMemory();
    checkFirmware();
    detectMalware();
    analyzeNetwork();
    checkKernelModules();
    scanRootkits();
    checkSuspiciousScripts();
    
    logEvent("Полное сканирование завершено");
}

void LibreAnti::backupBIOS(const string& output_file) {
    cout << "\n=== Резервное копирование BIOS ===\n";
    logEvent("Начало резервного копирования BIOS");
    
    if (!checkRootAccess()) {
        cerr << "Требуются права root!\n";
        return;
    }

    string filename = output_file.empty() ? generateBackupName() : output_file;
    
    try {
        execSystem("sudo flashrom -r " + filename);
        cout << "Резервная копия BIOS сохранена в: " << filename << "\n";
        logEvent("Резервная копия BIOS создана: " + filename);
    } catch (...) {
        cerr << "Ошибка резервного копирования BIOS\n";
        logEvent("Ошибка резервного копирования BIOS");
    }
}

void LibreAnti::scanWorms() {
    cout << "\n=== Поиск червей ===\n";
    logEvent("Начало поиска червей");
    
    try {
        cout << "[+] Поиск шаблонов червей:\n";
        execSystem("grep -r -E 'wget.*http|curl.*http' /tmp /var/tmp 2>/dev/null");
        
        cout << "\n[+] Проверка автозагрузки:\n";
        execSystem("ls -la /etc/init.d/ /etc/rc*.d/ /etc/cron* 2>/dev/null");
        
        logEvent("Поиск червей завершён");
    } catch (...) {
        cerr << "Ошибка поиска червей\n";
        logEvent("Ошибка поиска червей");
    }
}

void LibreAnti::checkOSIntegrity() {
    cout << "\n=== Проверка целостности ОС ===\n";
    logEvent("Начало проверки целостности ОС");
    
    try {
        cout << "[+] Проверка системных файлов:\n";
        execSystem("sudo debsums -e 2>/dev/null || echo 'Установите debsums для полной проверки'");
        
        cout << "\n[+] Проверка пакетов:\n";
        execSystem("sudo dpkg -V 2>/dev/null | grep -v 'cron'");
        
        logEvent("Проверка целостности ОС завершена");
    } catch (...) {
        cerr << "Ошибка проверки целостности ОС\n";
        logEvent("Ошибка проверки целостности ОС");
    }
}

void LibreAnti::detectHiddenProcesses() {
    cout << "\n[+] Поиск скрытых процессов:\n";
    
    try {
        execSystem("ps -eo pid | awk '{print $1}' | sort -n | uniq > /tmp/ps_pids");
        execSystem("ls /proc | grep -E '^[0-9]+$' | sort -n | uniq > /tmp/proc_pids");
        execSystem("diff /tmp/ps_pids /tmp/proc_pids | grep '>' | awk '{print \"Скрытый PID: \" $2}'");
        execSystem("rm /tmp/ps_pids /tmp/proc_pids 2>/dev/null");
        
        execSystem("find /proc/[0-9]*/ -maxdepth 1 -name cmdline -size 0 2>/dev/null | cut -d/ -f3 | xargs -I{} echo \"Процесс {} имеет пустой cmdline\"");
    } catch (...) {
        cerr << "Ошибка поиска скрытых процессов\n";
    }
}

// ===================== Остальные функции защиты =====================

void LibreAnti::behavioralAnalysis() {
    cout << "\n[BEHAVIORAL ANALYSIS]\n";
    logEvent("Starting behavioral analysis");
    
    cout << "[+] Process analysis (top 10 by CPU):\n";
    execSystem("ps aux --sort=-%cpu | head -n 11");
    
    cout << "\n[+] Base64 scripts detection:\n";
    execSystem("grep -r 'base64_decode(' /var/www /tmp 2>/dev/null");
    
    cout << "\n[+] Network connections:\n";
    execSystem("netstat -tulnpe | grep -v '127.0.0.1'");
    
    logEvent("Behavioral analysis completed");
}

void LibreAnti::memoryProtection() {
    if (!memory_protection_enabled) return;
    
    cout << "\n[MEMORY PROTECTION]\n";
    logEvent("Memory protection scan started");
    
    cout << "[+] Executable memory regions:\n";
    execSystem("sudo grep -i 'rwxp' /proc/*/maps 2>/dev/null | head -n 15");
    
    cout << "\n[+] Hidden processes detection:\n";
    detectHiddenProcesses();
    
    logEvent("Memory protection scan completed");
}

void LibreAnti::antiRansomware() {
    cout << "\n[ANTI-RANSOMWARE]\n";
    logEvent("Anti-ransomware scan started");
    
    cout << "[+] Encrypted files detection:\n";
    execSystem("find /home /tmp -type f -mtime -1 -exec file {} \\; | grep -i 'encrypted' 2>/dev/null");
    
    cout << "\n[+] Shadow copies check:\n";
    execSystem("sudo vssadmin list shadows 2>/dev/null || echo 'No shadow copies'");
    
    logEvent("Anti-ransomware scan completed");
}

void LibreAnti::cloudSandbox(const string& file_path) {
    if (!exists(file_path)) {
        cerr << "File not found!\n";
        return;
    }
    
    cout << "\n[CLOUD SANDBOX]\n";
    logEvent("Cloud sandbox analysis for: " + file_path);
    
    cout << "[+] Local analysis:\n";
    cout << "Size: " << file_size(file_path) << " bytes\n";
    cout << "SHA256: " << sha256_file(file_path) << "\n";
    execSystem("file " + file_path);
    
    cout << "\n[+] Signature check:\n";
    execSystem("grep -q 'ELF' " + file_path + " && echo 'Executable binary' || echo 'Not an executable'");
    
    logEvent("Cloud analysis completed for: " + file_path);
}

void LibreAnti::antiPhishing() {
    cout << "\n[ANTI-PHISHING]\n";
    logEvent("Anti-phishing scan started");
    
    cout << "[+] DNS cache analysis:\n";
    execSystem("sudo grep -i 'phish' /var/log/syslog 2>/dev/null");
    
    cout << "\n[+] SSL certificates:\n";
    execSystem("openssl s_client -connect example.com:443 < /dev/null 2>/dev/null | openssl x509 -noout -text | grep -i 'issuer\\|subject'");
    
    logEvent("Anti-phishing scan completed");
}

void LibreAnti::autoPatching() {
    cout << "\n[AUTO-PATCHING]\n";
    logEvent("Auto-patching started");
    
    if (!checkRootAccess()) {
        cerr << "Requires root privileges!\n";
        return;
    }
    
    cout << "[+] Checking updates:\n";
    execSystem("sudo apt-get update && sudo apt-get upgrade --dry-run");
    
    cout << "\n[+] Security updates:\n";
    execSystem("sudo unattended-upgrade --dry-run -v");
    
    logEvent("Auto-patching completed");
}

void LibreAnti::scanRootkits() {
    cout << "\n[ROOTKIT SCAN]\n";
    logEvent("Rootkit scan started");
    
    if (system("which rkhunter >/dev/null") == 0) {
        execSystem("sudo rkhunter --check --sk 2>/dev/null | grep -i 'warning'");
    } else {
        cout << "Install rkhunter for full scan\n";
    }
    
    execSystem("sudo chkrootkit -q 2>/dev/null | grep -v 'not infected'");
    
    logEvent("Rootkit scan completed");
}

void LibreAnti::checkSuspiciousScripts() {
    cout << "\n[SUSPICIOUS SCRIPTS]\n";
    logEvent("Suspicious scripts scan started");
    
    execSystem("find / -name '*.sh' -exec grep -lE 'wget\\|curl\\|base64' {} \\; 2>/dev/null | head -n 30");
    
    logEvent("Suspicious scripts scan completed");
}

void LibreAnti::monitorUSBChanges() {
    cout << "\n[USB MONITOR]\n";
    logEvent("USB monitoring started");
    
    execSystem("lsusb -v 2>/dev/null | grep -E 'idVendor|idProduct'");
    
    cout << "\n[+] Connection history:\n";
    execSystem("journalctl -k --grep='usb' | tail -n 10");
    
    logEvent("USB monitoring completed");
}

// ===================== Управление и меню =====================

void LibreAnti::setSecurityMode(SecurityMode mode) {
    current_mode = mode;
    logEvent("Security mode changed to: " + to_string(static_cast<int>(mode)));
}

void LibreAnti::enableMemoryProtection(bool enable) {
    memory_protection_enabled = enable;
    logEvent(string("Memory protection ") + (enable ? "enabled" : "disabled"));
}

void LibreAnti::showConsoleMenu() {
    int choice = 0;
    while (choice != 99) {
        system("clear");
        cout << "=== LibreAnti Ultimate ===\n"
             << "1. Full System Scan\n"
             << "2. BIOS Scan\n"
             << "3. USB Scan\n"
             << "4. Hardware Check\n"
             << "5. Memory Test\n"
             << "6. Firmware Check\n"
             << "7. Malware Scan\n"
             << "8. Network Analysis\n"
             << "9. Kernel Modules Check\n"
             << "10. BIOS Backup\n"
             << "11. Worm Scan\n"
             << "12. OS Integrity Check\n"
             << "13. Behavioral Analysis\n"
             << "14. Memory Protection\n"
             << "15. Anti-Ransomware\n"
             << "16. Cloud Sandbox\n"
             << "17. Anti-Phishing\n"
             << "18. Auto-Patching\n"
             << "19. Rootkit Scan\n"
             << "20. Suspicious Scripts\n"
             << "21. USB Monitor\n"
             << "99. Exit\n"
             << "Select option: ";
        cin >> choice;

        switch (choice) {
            case 1: fullSystemScan(); break;
            case 2: scanBIOS(); break;
            case 3: scanUSB(); break;
            case 4: checkHardware(); break;
            case 5: scanMemory(); break;
            case 6: checkFirmware(); break;
            case 7: detectMalware(); break;
            case 8: analyzeNetwork(); break;
            case 9: checkKernelModules(); break;
            case 10: backupBIOS(); break;
            case 11: scanWorms(); break;
            case 12: checkOSIntegrity(); break;
            case 13: behavioralAnalysis(); break;
            case 14: memoryProtection(); break;
            case 15: antiRansomware(); break;
            case 16: {
                string file;
                cout << "Enter file path: ";
                cin >> file;
                cloudSandbox(file);
                break;
            }
            case 17: antiPhishing(); break;
            case 18: autoPatching(); break;
            case 19: scanRootkits(); break;
            case 20: checkSuspiciousScripts(); break;
            case 21: monitorUSBChanges(); break;
            case 99: cout << "Exiting...\n"; break;
            default: cout << "Invalid option!\n";
        }
        
        if (choice != 99) {
            cout << "\nPress Enter...";
            cin.ignore();
            cin.get();
        }
    }
}

int LibreAnti::run() {
    if (!checkRootAccess()) {
        cout << "WARNING: Some features require root. Run with sudo!\n";
    }

    logEvent("=== LibreAnti started ===");
    showConsoleMenu();
    logEvent("=== LibreAnti stopped ===");
    
    return 0;
}
