#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <cstdlib>
#include <unordered_set>

#ifdef _WIN32
#include <windows.h>
#include <tlhelp32.h>
#include <winsock2.h>
#include <commctrl.h>
#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "comctl32.lib")
#else
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <dirent.h>
#include <pwd.h>
#include <gtk/gtk.h>
#endif

using namespace std;

// --- Общие функции ---
bool requestAdminAccess() {
    #ifdef _WIN32
    HANDLE hToken = NULL;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &hToken))
        return false;

    TOKEN_ELEVATION elevation;
    DWORD dwSize;
    if (!GetTokenInformation(hToken, TokenElevation, &elevation, sizeof(elevation), &dwSize)) {
        CloseHandle(hToken);
        return false;
    }
    CloseHandle(hToken);
    return elevation.TokenIsElevated;
    #else
    return getuid() == 0;
    #endif
}

// --- GUI-функции ---
#ifdef _WIN32
// Windows GUI с WinAPI
INT_PTR CALLBACK MainDialogProc(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch(msg) {
        case WM_INITDIALOG:
            return TRUE;
        case WM_COMMAND:
            switch(LOWORD(wParam)) {
                case IDC_SCAN_PROCESSES: {
                    HWND hList = GetDlgItem(hDlg, IDC_RESULTS_LIST);
                    SendMessage(hList, LB_RESETCONTENT, 0, 0);
                    
                    // Ваш код сканирования процессов
                    HANDLE hProcessSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
                    if (hProcessSnap != INVALID_HANDLE_VALUE) {
                        PROCESSENTRY32 pe32;
                        pe32.dwSize = sizeof(PROCESSENTRY32);
                        
                        if (Process32First(hProcessSnap, &pe32)) {
                            do {
                                string item = "PID: " + to_string(pe32.th32ProcessID) + " | Имя: " + pe32.szExeFile;
                                SendMessageA(hList, LB_ADDSTRING, 0, (LPARAM)item.c_str());
                            } while (Process32Next(hProcessSnap, &pe32));
                        }
                        CloseHandle(hProcessSnap);
                    }
                    break;
                }
                case IDC_EXIT:
                    EndDialog(hDlg, 0);
                    break;
            }
            break;
        case WM_CLOSE:
            EndDialog(hDlg, 0);
            break;
    }
    return FALSE;
}

void showGUI() {
    HINSTANCE hInstance = GetModuleHandle(NULL);
    DialogBox(hInstance, MAKEINTRESOURCE(IDD_MAIN_DIALOG), NULL, MainDialogProc);
}

#else
// Linux GUI с GTK
void on_scan_processes(GtkButton *button, gpointer user_data) {
    GtkTextBuffer *buffer = GTK_TEXT_BUFFER(user_data);
    gtk_text_buffer_set_text(buffer, "Сканирование процессов...\n", -1);
    
    FILE *fp = popen("ps aux", "r");
    if (fp) {
        char line[256];
        while (fgets(line, sizeof(line), fp)) {
            gtk_text_buffer_insert_at_cursor(buffer, line, -1);
        }
        pclose(fp);
    }
}

void showGUI() {
    GtkWidget *window, *vbox, *button, *scrolled_window, *text_view;
    GtkTextBuffer *buffer;
    
    gtk_init(0, NULL);
    
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "CyberStalker");
    gtk_window_set_default_size(GTK_WINDOW(window), 600, 400);
    
    vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
    gtk_container_add(GTK_CONTAINER(window), vbox);
    
    button = gtk_button_new_with_label("Сканировать процессы");
    g_signal_connect(button, "clicked", G_CALLBACK(on_scan_processes), buffer);
    gtk_box_pack_start(GTK_BOX(vbox), button, FALSE, FALSE, 0);
    
    scrolled_window = gtk_scrolled_window_new(NULL, NULL);
    text_view = gtk_text_view_new();
    buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(text_view));
    gtk_text_view_set_editable(GTK_TEXT_VIEW(text_view), FALSE);
    gtk_container_add(GTK_CONTAINER(scrolled_window), text_view);
    gtk_box_pack_start(GTK_BOX(vbox), scrolled_window, TRUE, TRUE, 0);
    
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);
    gtk_widget_show_all(window);
    gtk_main();
}
#endif

// --- Главная функция ---
int main(int argc, char* argv[]) {
    if (!requestAdminAccess()) {
        #ifdef _WIN32
        MessageBox(NULL, 
            L"Запустите программу от имени администратора!", 
            L"Ошибка", MB_ICONERROR);
        #else
        cout << "[!] ОШИБКА: Запустите программу от имени root!" << endl;
        #endif
        return 1;
    }

    // Проверка аргументов командной строки
    if (argc > 1 && string(argv[1]) == "--cli") {
        // Консольный режим (ваш оригинальный код)
        while (true) {
            cout << "\n1. Сканировать процессы\n2. Проверить автозагрузку\n3. Сканировать порты\n4. Выход\n";
            int choice; cin >> choice;
            // ... ваш оригинальный код меню ...
        }
    } else {
        // Графический режим
        #ifdef _WIN32
        INITCOMMONCONTROLSEX icc;
        icc.dwSize = sizeof(icc);
        icc.dwICC = ICC_WIN95_CLASSES;
        InitCommonControlsEx(&icc);
        #else
        gtk_init(&argc, &argv);
        #endif
        
        showGUI();
    }

    return 0;
}